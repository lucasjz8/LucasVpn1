package com.lucasvpn.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var connectButton: Button
    private var backend: GoBackend? = null
    private var tunnel: AppTunnel? = null
    private var config: Config? = null
    private val importRequest = 2001
    private val vpnRequest = 2002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(applicationContext)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 64, 48, 48)
        }
        val title = TextView(this).apply {
            text = "Lucas VPN"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Сначала импортируйте WireGuard-конфиг"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val importButton = Button(this).apply {
            text = "Импортировать конфиг"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(intent, importRequest)
            }
        }
        connectButton = Button(this).apply {
            text = "Подключить"
            isEnabled = false
            setOnClickListener { requestVpnPermissionAndConnect() }
        }
        val note = TextView(this).apply {
            text = "Нужен действующий файл WireGuard .conf от VPN-сервера."
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(status)
        root.addView(importButton)
        root.addView(connectButton)
        root.addView(note)
        setContentView(root)
    }

    @Deprecated("Legacy activity result API used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == importRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { input ->
                    if (input == null) throw IllegalStateException("Не удалось открыть файл")
                    config = Config.parse(input)
                }
                status.text = "Конфиг загружен. Можно подключаться."
                connectButton.isEnabled = true
            } catch (_: Exception) {
                config = null
                connectButton.isEnabled = false
                status.text = "Не удалось прочитать конфиг. Выберите файл WireGuard .conf."
            }
        } else if (requestCode == vpnRequest && resultCode == RESULT_OK) {
            toggleTunnel()
        }
    }

    private fun requestVpnPermissionAndConnect() {
        if (config == null) {
            status.text = "Сначала импортируйте WireGuard-конфиг"
            return
        }
        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) {
            startActivityForResult(permissionIntent, vpnRequest)
        } else {
            toggleTunnel()
        }
    }

    private fun toggleTunnel() {
        val b = backend ?: return
        val cfg = config ?: return
        if (tunnel == null) tunnel = AppTunnel()
        val t = tunnel!!
        connectButton.isEnabled = false
        thread {
            try {
                val nextState = if (b.getState(t) == Tunnel.State.UP) Tunnel.State.DOWN else Tunnel.State.UP
                b.setState(t, nextState, if (nextState == Tunnel.State.UP) cfg else null)
            } catch (_: Exception) {
                runOnUiThread { status.text = "Ошибка подключения. Проверьте конфиг и сервер." }
            } finally {
                runOnUiThread { connectButton.isEnabled = true }
            }
        }
    }

    inner class AppTunnel : Tunnel {
        override fun getName(): String = "LucasVPN"

        override fun onStateChange(newState: Tunnel.State) {
            runOnUiThread {
                if (newState == Tunnel.State.UP) {
                    status.text = "Подключено"
                    connectButton.text = "Отключить"
                } else {
                    status.text = if (config == null) "Импортируйте WireGuard-конфиг" else "Не подключено"
                    connectButton.text = "Подключить"
                }
            }
        }
    }
}
