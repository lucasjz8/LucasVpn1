# Lucas VPN

Android client for WireGuard.

## Build
The GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Connect to a VPN
Install the APK, then import a valid WireGuard `.conf` file provided by your VPN server. The app intentionally does not contain private keys or server credentials in source control.

A successful build does not itself provide VPN server access. You need an active WireGuard server and a valid client configuration.

## Security
Never commit WireGuard private keys or other credentials to this repository. If a key was previously shared publicly or in an untrusted place, rotate it.
